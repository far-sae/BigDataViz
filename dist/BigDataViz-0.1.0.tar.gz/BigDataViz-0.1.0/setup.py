from setuptools import setup, find_packages

setup(
    name="BigDataViz",
    version="0.1.0",
    author="Faraz Saeed Khwaja",
    author_email="saeedfaraz@gmail.com",
    description="A data visualization library optimized for large datasets.",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url="https://github.com/far-sae/BigDataViz",
    packages=find_packages(),
    install_requires=[
        'dask',
        'datashader',
        'matplotlib',
        'numpy',
    ],
    tests_require=['unittest'],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)